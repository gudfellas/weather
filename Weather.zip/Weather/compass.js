document.addEventListener('DOMContentLoaded', function () {
    if (window.DeviceOrientationEvent) {
        window.addEventListener('deviceorientation', handleOrientation);
    } else {
        alert("Device orientation not supported");
    }
});

function handleOrientation(event) {
    var compass = document.getElementById('compass');

    // Get the rotation angle
    var alpha = event.alpha;

    // Check if alpha (rotation angle) is available
    if (alpha !== null) {
        compass.style.transform = 'rotate(' + alpha + 'deg)';
    }
}
