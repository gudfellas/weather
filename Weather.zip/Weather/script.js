const apiKey = '41cd57d95ec76bcbd53da7502019de71';
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

const locationInput = document.getElementById('locationInput');
const searchButton = document.getElementById('searchButton');
const locationElement = document.getElementById('location');
const temperatureElement = document.getElementById('temperature');
const pressureElement = document.getElementById('pressure');
const humidityElement = document.getElementById('humidity');
const windspeedElement = document.getElementById('wind_speed');
const winddirectionElement = document.getElementById('wind_direction');
const compassImage = document.getElementById('compassImage');
const descriptionElement = document.getElementById('description');

/* searchButton.addEventListener('click', () => {
    const location = locationInput.value;
    if (location) {
        fetchWeather(location);
    }
}); */

searchButton.addEventListener('click', () => {
    const location = locationInput.value.trim();
    if (location) {
        showLoadingIndicator();
        fetchWeather(location)
            .finally(() => hideLoadingIndicator());
    } else {
        alert('Please enter a valid location.');
    }
});

function showLoadingIndicator() {
    // Implement a loading indicator display logic (e.g., change button text or show a spinner)
}

function hideLoadingIndicator() {
    // Implement a loading indicator hide logic (e.g., revert button text or hide the spinner)
}

function fetchWeather(location) {
    const url = `${apiUrl}?q=${location}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            locationElement.textContent = data.name;
            temperatureElement.textContent = `${Math.round(data.main.temp)} °C`;
            pressureElement.textContent = `${Math.round(data.main.pressure)} hPa`;
            humidityElement.textContent = `${Math.round(data.main.humidity)} %`;
            windspeedElement.textContent = `${Math.round(data.wind.speed)} m/s`;
            winddirectionElement.textContent = `${Math.round(data.wind.deg)} °`;

            rotateCompassImage(data.wind.deg);

            descriptionElement.textContent = data.weather[0].description;
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
        });
}

function rotateCompassImage(degrees) {
    // Calculate the difference between the wind direction and 0 degrees (north)
    // This difference is used to rotate the arrow relative to the background
    const arrowRotation = degrees - 0;

    // Apply the rotation to the arrow
    compassImage.style.transform = `translate(-50%, -50%) rotate(${arrowRotation}deg)`;
}
